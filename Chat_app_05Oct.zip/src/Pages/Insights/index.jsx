import React from 'react';

const index = () => {
    return (
        <div>
            Insight
        </div>
    );
};

export default index;