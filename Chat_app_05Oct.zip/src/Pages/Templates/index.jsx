import React from 'react';

const index = () => {
    return (
        <div>
            Template
        </div>
    );
};

export default index;