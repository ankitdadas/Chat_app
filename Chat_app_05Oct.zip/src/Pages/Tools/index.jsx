import React from 'react';

const index = () => {
    return (
        <div>
            Tools
        </div>
    );
};

export default index;