import React from 'react';

const index = () => {
    return (
        <div>
          Feature Request  
        </div>
    );
};

export default index;