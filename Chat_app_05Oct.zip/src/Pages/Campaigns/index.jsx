import React from "react";

const index = () => {
  return <div>Campaign</div>;
};

export default index;
