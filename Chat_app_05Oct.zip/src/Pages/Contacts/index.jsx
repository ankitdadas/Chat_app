import React from 'react';

const index = () => {
    return (
        <div>
          Contacts  
        </div>
    );
};

export default index;